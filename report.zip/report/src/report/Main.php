<?php

namespace report;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\player\GameMode;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    private Config $reportData;

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->reportData = new Config($this->getDataFolder() . 'reports.yml', Config::YAML, []);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info('§aReportSystem is now active!');
    }

    public function onDisable(): void {
        $this->reportData->save();
        $this->getLogger()->info('§cReportSystem has been disabled, data saved.');
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage('§cThis command can only be used by players.');
            return true;
        }
        $name = strtolower($command->getName());
        if ($name === 'report') {
            if (!$sender->hasPermission('report.use')) {
                $sender->sendMessage('§cYou do not have permission to use this command.');
                return true;
            }
            $this->openReportMenu($sender);
            return true;
        }
        if ($name === 'reports') {
            if (!$sender->hasPermission('report.view')) {
                $sender->sendMessage('§cYou do not have permission to view reports.');
                return true;
            }
            $this->openReportsMenu($sender);
            return true;
        }
        return false;
    }

    private function openReportMenu(Player $player): void {
        $online = $this->getServer()->getOnlinePlayers();
        $targets = [];
        foreach ($online as $p) {
            if ($p->getName() !== $player->getName()) {
                $targets[] = $p->getName();
            }
        }
        $form = new SimpleForm(function (Player $p, $data) use ($targets) {
            if ($data === null) return;
            $index = (int)$data;
            if (!isset($targets[$index])) return;
            $this->openReasonMenu($p, $targets[$index]);
        });
        $form->setTitle('§bReport a Player');
        if (empty($targets)) {
            $form->setContent('§eNo other players online to report.');
            $form->addButton('§cClose');
        } else {
            $form->setContent('§eSelect a player to report:');
            foreach ($targets as $index => $name) {
                $form->addButton($name);
            }
        }
        $player->sendForm($form);
    }

    private function openReasonMenu(Player $player, string $target): void {
        if ($target === $player->getName()) {
            $player->sendMessage('§cYou cannot report yourself.');
            return;
        }
        $form = new CustomForm(function (Player $p, $data) use ($target) {
            if ($data === null) return;
            $reason = trim((string)($data[0] ?? ''));
            if ($reason === '') {
                $p->sendMessage('§cYou must enter a reason for reporting.');
                return;
            }
            $this->reportData->set($target, [
                'reporter' => $p->getName(),
                'target'   => $target,
                'reason'   => $reason,
                'time'     => date('Y-m-d H:i:s')
            ]);
            $this->reportData->save();
            $p->sendMessage("§aYour report against {$target} for reason '{$reason}' has been submitted.");
        });
        $form->setTitle('§bEnter Report Reason');
        $form->addInput('§eType the reason for reporting:', '', '');
        $player->sendForm($form);
    }

    private function openReportsMenu(Player $player): void {
        $reports = $this->reportData->getAll();
        $targets = array_keys($reports);
        $form = new SimpleForm(function (Player $p, $data) use ($targets) {
            if ($data === null) return;
            $index = (int)$data;
            if (!isset($targets[$index])) return;
            $this->openReportDetails($p, $targets[$index]);
        });
        $form->setTitle('§bReports List');
        if (empty($targets)) {
            $form->setContent('§eNo reports have been submitted.');
            $form->addButton('§cClose');
        } else {
            $form->setContent('§eSelect a reported player:');
            foreach ($targets as $name) {
                $form->addButton($name);
            }
        }
        $player->sendForm($form);
    }

    private function openReportDetails(Player $player, string $target): void {
        if (!$this->reportData->exists($target)) {
            $player->sendMessage('§cReport not found.');
            return;
        }

        $report = $this->reportData->get($target);

        // Validate report data
        if (!is_array($report) || !isset($report['reporter'], $report['reason'], $report['time'])) {
            $player->sendMessage("§cCorrupted report data for {$target}.");
            return;
        }

        $tp = $this->getServer()->getPlayerExact($target);
        $status = $tp !== null ? '§2Online' : '§4Offline';
        $ip = ($tp !== null && $tp->isConnected()) ? $tp->getNetworkSession()->getIp() : 'Unknown';
        $gm = ($tp !== null && $tp->isConnected()) ? $tp->getGamemode() : null;
        $mode = $gm !== null ? match (true) {
            $gm->equals(GameMode::SURVIVAL()) => 'Survival',
            $gm->equals(GameMode::CREATIVE()) => 'Creative',
            $gm->equals(GameMode::ADVENTURE()) => 'Adventure',
            $gm->equals(GameMode::SPECTATOR()) => 'Spectator',
            default => 'Unknown',
        } : 'Unknown';

        $content = "§eReporter: §f{$report['reporter']}\n";
        $content .= "§eTarget: §f{$target}\n";
        $content .= "§eReason: §f{$report['reason']}\n";
        $content .= "§eTime: §f{$report['time']}\n";
        $content .= "§eIP: §f{$ip}\n";
        $content .= "§eGame Mode: §f{$mode}\n";
        $content .= "§eStatus: §f{$status}";

        $form = new SimpleForm(function (Player $p, $data) use ($target) {
            if ($data === null) return;
            if ((int)$data === 1) {
                $this->reportData->remove($target);
                $this->reportData->save();
                $p->sendMessage("§aReport against {$target} has been reviewed and removed.");
            }
        });

        $form->setTitle('§bReport Details');
        $form->setContent($content);
        $form->addButton('§bBack');
        $form->addButton('§cRemove Report');
        $player->sendForm($form);
    }
}